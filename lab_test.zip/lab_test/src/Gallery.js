import React, {Component} from 'react';
import './style/GalleryStyle.css';
import SportYoga from './img/SportYoga.jpg';
import facebook from './img/facebook.png';
import instagram from './img/instagram.png';
import twitter from './img/twitter.png';

export class Gallery extends Component {
    constructor(props) {
        super(props);
        this.state = { }
    }
    render() {
        return (
            <section>
                <div className="main_foto_page2">
                    <img src={SportYoga} className="SportYoga" alt="sport_girl_Yoga" />
                    <div className="elem_foto">
                        <div className="cir_5"></div>
                        <div className="cir_6"></div>
                        <div className="cir_7"></div>
                    </div>
                </div>



                <h1>Adult Open <br/> Division Classes.</h1>
                <h3><span>Yoga &mdash;</span><br/>Alisa Nikolskaya</h3>

                <h6 className="elem_1">qbc &mdash;&mdash;&mdash; DANCE CLASSIC</h6>
                <h6 className="elem_2">qbc</h6>
                <h6 className="elem_3"><span>&mdash;&mdash;&mdash; 02 &#9899;</span> &#9899; &#9899; &#9899; </h6>
                <h6 className="elem_4">for<br/> children</h6>
                <h6 className="elem_5">&mdash;&mdash;&mdash; Timetable September 2016 &mdash; July 2017</h6>
                <div className="contacts_page2">
                    <h6 className="tel_page2">T: +7 495 123 45 67</h6>
                    <h6 className="site_page2">qbc@holder.com</h6>
                </div>



                <h5>Adults interested in balet adult contemporary<br/>temporery technique and expends on the basic movement<br/>flexibility to accomodate their busy schedule<br/>through the pbt school open division.</h5>

                <div className="follow_page2">
                    <a href="#"><img src={instagram} className="instagram_page2" alt="instagram" /></a>
                    <a href="#"><img src={twitter} className="twitter_page2" alt="twitter" /></a>
                    <a href="#"><img src={facebook} className="facebook_page2" alt="facebook" /></a>


                </div>
                <div className="registration_page2">
                    <a className="buttReg_page2" href="#"> </a>
                    <h6 className="regName_page2">Registration</h6>
                </div>
            </section>
        );
    }
}

export default Gallery;