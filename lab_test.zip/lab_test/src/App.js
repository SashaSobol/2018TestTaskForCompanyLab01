import React, { Component } from 'react';
// import logo from './logo.png';
// import trigger from './trigger.png';
import './style/App.css';
import Menu from './Menu';
import Gallery from './Gallery';
import About from './About';
import Contact from './Contact';



class App extends Component {
    constructor(props) {
        super(props);

        this.state = {
            navSelected: 'gallery',
        };
    }

    handleNavClick = event => {
        this.setState({navSelected: event.target.getAttribute('name')});
    };



  render() {
      const {navSelected} = this.state;

    return (
      <div className="App">
        <header className="App-header">
            <nav>

                <div className="logo">OOC
                    <div className="elem">
                        <div className="cir_1 circl"></div>
                        <div className="cir_2 circl"></div>
                    </div>
                </div>

                <ul>
                    <li>
                        <a className="activeMenu"
                           name="menu"
                           onClick={this.handleNavClick}
                           selected={navSelected === 'menu'}
                           href="#">Menu</a>
                    </li>
                        <li>
                            <a className="activeMenu"
                                name="gallery"
                               onClick={this.handleNavClick}
                               selected={navSelected === 'gallery'}
                                href="#">Gallery</a>
                        </li>
                        <li>
                            <a className="activeMenu"
                                name="about"
                                onClick={this.handleNavClick}
                                selected={navSelected === 'about'}
                                href="#">About</a>
                        </li>
                        <li>
                            <a className="activeMenu"
                                name="contact"
                               onClick={this.handleNavClick}
                               selected={navSelected === 'contact'}
                                href="#">Contact</a>
                        </li>
                </ul>

                <div className="lengvich">
                    <ul>
                        <li>
                            <a className="len_1" href="#">EN</a>
                        </li>
                        <li>
                            <a className="len_1" href="#">RU</a>
                        </li>
                    </ul>
                </div>
            </nav>



            {/*<img src={trigger} className="trigger" alt="trigger" />*/}


            {navSelected === 'menu' ? <Menu /> :
                navSelected === 'gallery' ? <Gallery /> :
                    navSelected === 'about' ? <About /> : <Contact /> }
        </header>
        <p className="App-intro">
        </p>
      </div>
    );
  }
}

export default App;
