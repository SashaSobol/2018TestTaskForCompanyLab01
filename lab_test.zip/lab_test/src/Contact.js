import React, {Component} from 'react';

export class Contact extends Component {
    constructor(props) {
        super(props);
        this.state = { }
    }
    render() {
        return <div>Contact</div>;
    }
}

export default Contact;