import React, {Component} from 'react';
import Sport from './img/Sport.png';
import './style/MenuStyle.css';
import facebook from './img/facebook.png';
import instagram from './img/instagram.png';
import twitter from './img/twitter.png';


export class Menu extends Component {
    constructor(props) {
        super(props);
        this.state = { }
    }
    render() {
        return (
            <main>
                <div className="main_foto">
                    <img src={Sport} className="Sport" alt="sport_girl" />
                    <div className="elem_foto">
                        <div className="cir_3"></div>
                        <div className="cir_4"></div>
                    </div>
                </div>



                <h1><span>String Intensives</span> &mdash; <br/> Applications now <br/>being accepted.</h1>
                <h3><span>Contemporary &mdash;</span><br/>Alexandra Sorokina</h3>

                <h6 className="elem_1">qbc &mdash;&mdash;&mdash; DANCE CLASSIC</h6>
                <h6 className="elem_2">qbc</h6>
                <h6 className="elem_3"><span>&mdash;&mdash;&mdash; 01 &#9899;</span> &#9899; &#9899; &#9899; </h6>

                <div className="contacts">
                    <h6 className="tel">T: +7 495 123 45 67</h6>
                    <h6 className="site">qbc@holder.com</h6>
                </div>



                <h5>This 11 week course increases your understanding of Con-<br/>temporery technique and expends on the basic movement<br/>vocabulary learnt in the intreduction course, building your<br/>confidence to progress to Level 1.</h5>

                <div className="follow">
                    <a href="#"><img src={instagram} className="instagram" alt="instagram" /></a>
                    <a href="#"><img src={twitter} className="twitter" alt="twitter" /></a>
                    <a href="#"><img src={facebook} className="facebook" alt="facebook" /></a>


                </div>
                    <div className="registration">
                    <a className="buttReg" href="#"> </a>
                <h6 className="regName">Registration</h6>
                    </div>
            </main>
        );
    }
}

export default Menu;