import React, {Component} from 'react';

export class About extends Component {
    constructor(props) {
        super(props);
        this.state = { }
    }
    render() {
        return <div>About</div>;
    }
}

export default About;